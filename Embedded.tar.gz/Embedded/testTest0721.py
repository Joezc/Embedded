import transTest
import serial
import time
input=256
ser = serial.Serial('/dev/ttyS0', 9600, timeout=1)
while 1:
    time.sleep(5)
    output=transTest.transdata(ser,input)

    print(output[0]*256,int(output[1]))
#print(type(output[0]),type(output[1]))
