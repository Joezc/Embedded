from vertexTest import Vertex
import urlTest
import json
import time
import math
import sys
import IOwithSpeak
import shakeHands
import serial
import transTest
MAXN = 100000000

class Graph(object):

    def __init__(self):
        """ initializes a graph object """
        """ figure out what to store internally for a graph"""
        self.vertexList = []
        self.nodeNum = 0

    def __str__(self):
        """ print out the vertices and edges """
        list1 = []
        for v in self.vertexList:
            list1.append(v.name)

        return str(list1)+str(self.edgeMatrix)

    def init_edges(self):
        self.edgeMatrix = [[(-1, -1) for x in range(self.nodeNum)] for y in range(self.nodeNum)]

    def addVertex(self, v):
        self.vertexList.append(v)
        self.nodeNum = self.nodeNum+1

    def addEdge(self, v1, v2):
        self.edgeMatrix[v1-1][v2-1]=(self.vertexList[v1-1].caculateDis(self.vertexList[v2-1]), self.vertexList[v1-1].caculateAng(self.vertexList[v2-1]))

    def dijkstra(self, begin, end):
        graph = self.edgeMatrix
        n = self.nodeNum

        begin = begin-1
        end = end-1

        dis=[0]*n
        flag=[False]*n
        pre=[0]*n

        flag[begin]=True
        k=begin

        for i in range(n):
            dis[i]=(graph[k][i])[0]
        dis[begin] = 0
        #print(str(dis))
        for j in range(n-1):
            mini=MAXN
            for i in range(n):
                if ((dis[i]!=-1) and (dis[i]<mini)) and (not flag[i]):
                    mini=dis[i]
                    k=i
            if mini==MAXN:
                return
            flag[k]=True
            for i in range(n):
                if (graph[k][i][0]!=-1) and ((dis[i]>dis[k]+graph[k][i][0]) or (dis[i]==-1)):
                    dis[i]=dis[k]+graph[k][i][0]
                    pre[i]=k


        dic = {}
        dic['value'] = dis[end]
        dic['route']=[]
        now = end
        while pre[now]!=0:
            dic['route'].append(now+1)
            now = pre[now]
        dic['route'].append(now+1)
        dic['route'].append(begin+1)
        dic['route'].reverse()
        return dic

if __name__ == "__main__":
    # load map information

    # while True:
    #     jsonStr = urlTest.loadMap()
    #     if (jsonStr != 'fail'):
    #         break
    f = open('./map/1_1')
    jsonStr = f.readlines()[0]
    map1 = json.loads(jsonStr)
    print("number of nodes is %d, the name of the first node is %s" % (len(map1['map']), map1['map'][0]['nodeName']))

    print("number of nodes is %d, the name of the first node is %s" % (len(map1['map']), map1['map'][0]['nodeName']))

    g = Graph()
    north=int(map1['info']['northAt'])
    for node in map1['map']:
        v = Vertex(node['nodeName'], int(node['x']), int(node['y']), int(node['nodeId']))
        g.addVertex(v)

    g.init_edges()
    for node in map1['map']:
        v = Vertex(node['nodeName'], int(node['x']), int(node['y']), int(node['nodeId']))
        string1 = node["linkTo"]
        list1 = string1.split(',')
        list2=[]
        for celement in list1:
            list2.append(celement.strip())

        for linkedNode in list2:
            g.addEdge(int(node['nodeId']), int(linkedNode))

   #print("")
   # IOwithSpeak.outputWithVoice("Be sure the following vertexs are under %d" % g.nodeNum)
    begin = IOwithSpeak.inputWithVoice("please input the starting vertex:")
    while(int(begin)>g.nodeNum or int(begin)<=0):
        IOwithSpeak.outputWithVoice("the vertex number is overflowing. ")
        begin = IOwithSpeak.inputWithVoice("please input a starting vertex under "+str(g.nodeNum))
    end = IOwithSpeak.inputWithVoice("please input an ending vertex:")
    while(int(end)>g.nodeNum or int(begin)<=0):
        IOwithSpeak.outputWithVoice("the vertex number is overflowing. ")
        end = IOwithSpeak.inputWithVoice("please input an ending vertex under "+str(g.nodeNum))
    sh_route=g.dijkstra(int(begin), int(end))['route']
#    IOwithSpeak.outputWithVoice("the shortest path from "+begin+" to "+end+" is "+str(sh_route))
    ser = serial.Serial('/dev/ttyS0', 9600, timeout=1)
    shakeHands.shake(ser)
    try:
        while 1:
#            print("1")
            print(begin,str(sh_route))
            ser.write(g.vertexList[sh_route[0]-1].x.to_bytes(2,byteorder='big'))
#            print(g.vertexList[sh_route[0]-1].x)
            ser.write(g.vertexList[sh_route[0]-1].y.to_bytes(2, byteorder='big'))
#            print(g.vertexList[sh_route[0]-1].y)
            ser.write(north.to_bytes(2, byteorder='big'))
#            print(north)
            if_Init=ser.read(2)
#            print("5")
            if(if_Init==b'FF'):
                print("be ready to break")
                break;
            else:
                print(if_Init)
                print("if_Init_Bytes_Error")
    except KeyboardInterrupt:
        ser.close()
    current=0
    #shakeHands.shake(ser)
    ax = -(g.vertexList[sh_route[current]-1].x - g.vertexList[sh_route[current]].x)
    ay = -(g.vertexList[sh_route[current]-1].y - g.vertexList[sh_route[current]].y)
#    print("ax+ay"+str(ax)+str(ay))
    ang_ret= int(math.atan2(ax, ay) * 180 / 3.14159)
    ang_ret=ang_ret%360
#    current_time=time.time()
    speakFlag_Reach = True
    speakFlag_Direction = True
    speakFlag_Switch = True
    while(True):
    #    print(time.time()-current_time)
        if(True):
        #    time.sleep(3)
        #    ser = serial.Serial('/dev/ttyS0', 9600, timeout=1)
        #       current_time=time.time()
        #	if(time.time()-current_time>1000):
            print("ang_ret:")
            print(ang_ret)
            data_From_Arduino=transTest.transdata(ser,ang_ret)
            sonar_left=data_From_Arduino[6]*256+data_From_Arduino[7]
            sonar_right=data_From_Arduino[8]*256+data_From_Arduino[9]
            sonar_front=data_From_Arduino[10]*256+data_From_Arduino[11]
            current_X=data_From_Arduino[0]*256+data_From_Arduino[1]
            current_Y=data_From_Arduino[2]*256+data_From_Arduino[3]
            current_Angel=data_From_Arduino[4]*256+data_From_Arduino[5]
#            sonarFlag=set_Sonar_Flag(sonar_left,sonar_right,sonar_front)
            ###
            print(sonar_left,sonar_right,sonar_front,current_X,current_Y,current_Angel)
       #current_X = int(IOwithSpeak.inputWithVoice("current X: "))
            #current_Y = int(IOwithSpeak.inputWithVoice("current Y: "))
            #current_Angel=int(IOwithSpeak.inputWithVoice("current heading: "))
               # while(current_Angel>=360):
            #    IOwithSpeak.outputWithVoice("wrong heading data, please input again")
             #   current_Angel=int(IOwithSpeak.inputWithVoice("current heading: "))

            if abs(g.vertexList[sh_route[current]-1].x-int(current_X))<=25 and abs(g.vertexList[sh_route[current]-1].y-int(current_Y))<=25:
        #            begin=sh_route[current]

                if (int(sh_route[current]) == int(end)):
                    IOwithSpeak.outputWithVoice("reach the destination. navigation ends")
                    data_From_Arduino=transTest.transdata(ser,65535)
                    time.sleep(2)
                    sys.exit()
                if (speakFlag_Reach):
                    IOwithSpeak.outputWithVoice("reach vertex "+str(sh_route[current]))
                    speakFlag_Reach=False
                    current=current+1
            else:
                speakFlag_Reach=True
            ang_change=5
            ax = -(current_X - g.vertexList[sh_route[current]-1].x)
            ay = -(current_Y - g.vertexList[sh_route[current]-1].y)
            ###angs:ang_cal(0,360,campass),ang_ret(0,360,xyangel),current_ang(0,360,campass),ang_diff(-360,360)
            ang_ret=ang_cal = int(math.atan2(ax, ay) * 180 / 3.14159)
            ang_ret=ang_ret%360
#           if(sonar_left != 0 and sonar_right !=0):
 #               if(sonar_left-sonar_right>10):
 #                   ang_ret=(ang_ret-ang_change)%360
 #               elif(sonar_right-sonar_left>10):
 #                   ang_ret=(ang_ret+ang_change)%360
            ###
 #           print("ax,ay"+str(ax)+str(ay))
            # print('ang_cal1= %d' % ang_cal)
            ang_cal = (360-north+ang_cal) % 360
            ang_diff = ang_cal - current_Angel

            # print('ang_cal= %d' % ang_cal)
            # print('ang_diff= %d' % ang_diff)

            ang_precison = 5
            if (ang_diff >= -360 and ang_diff <= -360 + ang_precison):
                if (speakFlag_Direction):
                    speakFlag_Direction=False
                    speakFlag_Switch=False
                    IOwithSpeak.outputWithVoice("keep straight forward")
                else:
                    if (speakFlag_Switch):
                        speakFlag_Direction=True
            elif (ang_diff > -360 + ang_precison and ang_diff <= -180 - ang_precison):
                if (speakFlag_Direction):
                    speakFlag_Direction = False
                    speakFlag_Switch = True
                    IOwithSpeak.outputWithVoice("turn right " + str(ang_diff + 360) + " degree")
            elif (ang_diff > -180 - ang_precison and ang_diff <= -180 + ang_precison):
                if (speakFlag_Direction):
                    speakFlag_Direction = False
                    speakFlag_Switch = True
                    IOwithSpeak.outputWithVoice("turn about")
            elif (ang_diff > -180 + ang_precison and ang_diff <= -ang_precison):
                if (speakFlag_Direction):
                    speakFlag_Direction = False
                    speakFlag_Switch = True
                    IOwithSpeak.outputWithVoice("turn left " + str(-ang_diff) + " degree")
            elif (ang_cal > -ang_precison and ang_diff <= ang_precison):
                if (speakFlag_Direction):
                    speakFlag_Direction = False
                    speakFlag_Switch = False
                    IOwithSpeak.outputWithVoice("keep straight forward")
                else:
                    if (speakFlag_Switch):
                        speakFlag_Direction = True
            elif (ang_diff > ang_precison and ang_diff <= 180 - ang_precison):
                if (speakFlag_Direction):
                    speakFlag_Direction = False
                    speakFlag_Switch = True
                    IOwithSpeak.outputWithVoice("turn right " + str(ang_diff) + " degree")
            elif (ang_diff > 180 - ang_precison and ang_diff <= 180 + ang_precison):
                if (speakFlag_Direction):
                    speakFlag_Direction = False
                    speakFlag_Switch = True
                    IOwithSpeak.outputWithVoice("turn about")
            elif (ang_diff > 180 + ang_precison and ang_diff < 360 - ang_precison):
                if (speakFlag_Direction):
                    speakFlag_Direction = False
                    speakFlag_Switch = True
                    IOwithSpeak.outputWithVoice("turn left " + str(360 - ang_diff) + " degree")
            elif (ang_diff >= 360 - ang_precison and ang_diff <= 360):
                if (speakFlag_Direction):
                    speakFlag_Direction = False
                    speakFlag_Switch = False
                    IOwithSpeak.outputWithVoice("keep straight forward")
                else:
                    if (speakFlag_Switch):
                        speakFlag_Direction = True
        #        IOwithSpeak.outputWithVoice("the next position should be "+str(sh_route[current]))
#            print(str(nowDis))
            nowDis  = math.sqrt(float( (g.vertexList[sh_route[current]-1].x-int(current_X) )**2 ) +float( (g.vertexList[sh_route[current]-1].y-int(current_Y) )**2) )
            nowDis = int(nowDis)
            if(speakFlag_Direction):
                IOwithSpeak.outputWithVoice(str(nowDis)+" centimeters to the next position: "+str(sh_route[current])+" "+str(g.vertexList[sh_route[current]].name))
         #   current_time=time.time()
         #       print(str(g.dijkstra(int(begin),int(end))))

def set_Sonar_Flag(sonar_left,sonar_right,sonar_front):
    sonarLeftFlag=sonarRightFlag=sonarFrontFlag=0
    if(sonar_left<15):
        sonarLeftFlag=1
    if(sonar_right<15):
        sonarRightFlag=1
    if(sonar_front<15):
        sonarFrontFlag=1
    return sonarLeftFlag*100+sonarRightFlag*10+sonarFrontFlag

def judge(ang_diff):
    if(abs(ang_diff)<=30):
        return "front"
    elif(ang_diff<=150):
        return "right"
    elif(ang_diff>=-150):
        return "left"
    else:
        return "back"
        current_X = int(IOwithSpeak.inputWithVoice("current X: "))
        current_Y = int(IOwithSpeak.inputWithVoice("current Y: "))
        current_Angel=int(IOwithSpeak.inputWithVoice("current Angel: "))

        if abs(g.vertexList[sh_route[current]-1].x-int(current_X))<=25 and abs(g.vertexList[sh_route[current]-1].y-int(current_Y))<=25:
            # begin=sh_route[current]
            if (int(sh_route[current]) == int(end)):
                IOwithSpeak.outputWithVoice("get the destination")
                sys.exit()
            current=current+1

        ax = -(current_X - g.vertexList[sh_route[current]-1].x)
        ay = -(current_Y - g.vertexList[sh_route[current]-1].y)
        ang_cal = int(math.atan2(ax, ay) * 180 / 3.14159)
        # print('ang_cal1= %d' % ang_cal)
        ang_cal = (360-north+ang_cal) % 360
        ang_diff = ang_cal - current_Angel

        # print('ang_cal= %d' % ang_cal)
        # print('ang_diff= %d' % ang_diff)

        ang_precison = 5
        if (ang_diff >= -360 and ang_diff <= -360 + ang_precison):
            IOwithSpeak.outputWithVoice("keep straight forward")
        elif (ang_diff > -360 + ang_precison and ang_diff <= -180 - ang_precison):
            IOwithSpeak.outputWithVoice("turn right "+str(ang_diff+360))
        elif (ang_diff > -180 - ang_precison and ang_diff <= -180 + ang_precison):
            IOwithSpeak.outputWithVoice("turn about")
        elif (ang_diff > -180 + ang_precison and ang_diff <= -ang_precison):
            IOwithSpeak.outputWithVoice("turn left "+str(-ang_diff))
        elif (ang_cal > -ang_precison and ang_diff <= ang_precison):
            IOwithSpeak.outputWithVoice("keep straight forward")
        elif (ang_diff > ang_precison and ang_diff <= 180 - ang_precison):
            IOwithSpeak.outputWithVoice("turn right "+str(ang_diff))
        elif (ang_diff > 180 -ang_precison and ang_diff <= 180 + ang_precison):
            IOwithSpeak.outputWithVoice("turn about")
        elif (ang_diff > 180 + ang_precison and ang_diff < 360 - ang_precison):
            IOwithSpeak.outputWithVoice("turn left "+str(360-ang_diff))
        elif (ang_diff >= 360 - ang_precison and ang_diff <= 360):
            IOwithSpeak.outputWithVoice("keep straight forward")

        nowDis  = math.sqrt(float( (g.vertexList[sh_route[current]-1].x-int(current_X) )**2 ) +float( (g.vertexList[sh_route[current]-1].y-int(current_Y) )**2) )
        nowDis = int(nowDis)

        IOwithSpeak.outputWithVoice("the next position should be "+str(sh_route[current]))
        IOwithSpeak.outputWithVoice("the distance is "+str(nowDis))

        # print(str(g.dijkstra(int(begin),int(end))))
