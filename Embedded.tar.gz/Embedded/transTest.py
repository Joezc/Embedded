"check if arduino is well connected to Pi"
import serial
def transdata(ser,input): 
#ser = serial.Serial('/dev/ttyS0', 9600, timeout=1)
    #input1=260
    #input2=2000
    input=input.to_bytes(2,byteorder='big')
    try:
        while 1:
       # print(input1)
            ser.write(input)#angel
            response =ser.read(12)
            if(response!=b''):
                print(response)
                return response #sonar1_left,sonar2_right,sonar3_front,x,y,heading
            else:
                print("normal connection error")
    except KeyboardInterrupt:
        ser.close()
