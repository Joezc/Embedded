from espeak import espeak
import numberpad

def inputWithVoice(inStr):
    outputWithVoice(inStr)
    temp =str(numberpad.inputWithNumPad())
    outputWithVoice(temp)
    return temp

def outputWithVoice(outStr):
    espeak.synth(outStr)
    print(outStr)
