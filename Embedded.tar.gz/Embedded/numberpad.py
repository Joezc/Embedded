import evdev,sys,time
from espeak import espeak

def inputWithNumPad():
    dev = evdev.InputDevice('/dev/input/event0')
    dic = {82:0,79: 1, 80: 2, 81: 3, 75: 4, 76: 5, 77: 6, 71: 7, 72: 8, 73: 9, 96: 10,83:11,14:12,69:14,98:14,55:14,74:14,78:14}
    temp=0
    flag=False
    for event in dev.read_loop():
        if(event.value==1):
            if(dic[event.code]==10):
                espeak.synth("exit")
                time.sleep(1)
                break
            elif(dic[event.code]==11):
                temp=temp*100
                espeak.synth("double"+str(0))
            elif(dic[event.code]==12):
                temp=int((temp-temp%10)/10)
                espeak.synth("back space")
            elif(dic[event.code]==13):
                if(flag==True):
                    flag=False
                    break
                else:
                    flag=True
                    espeak.synth("the number pad has been locked, please press again to unlock")
            elif(dic[event.code]!=14):
                temp=temp*10+dic[event.code]
                espeak.synth(str(dic[event.code]))
            else:
                espeak.synth("error, please input again")
#                print(event.code)
#                espeak.synth(str(temp))
#                IOwithSpeak.outputWithVoice(temp)
    return temp

#inputWithNumPad()
