import math

def avoidance(sonar_1,sonar_2,sonar_3,ang_ret,thres,command_1,command_2):
    if(sonar_1<thres):
        if(sonar_2<thres):
            if(sonar_3<thres):
                ret=65535
            else:
                ret=turn(command_1,ang_ret,int(math.atan2(sonar_2,sonar_1)*180/3.14159))
        else:
            if(sonar_3<thres):
                ret=turn(command_2,ang_ret,int(math.atan2(sonar_3,sonar_1)*180/3.14159))
            else:
                ret=turn(command_1,ang_ret,90)
    else:
        goStraight()

def turn(command,ang_ret,ang):
    if(command=="left"):
        ret=(ang_ret-ang)%360
    elif(command=="right"):
        ret=(ang_ret+ang)%360
    return ret


def goStraight(sonar_)
