"check if arduino is well connected to Pi"
import serial

def shake(ser):
    ACK=b'B'
    ACK1=bytes([0x11])
    Hello=bytes([0x12])     
    #ser = serial.Serial('/dev/ttyS0', 9600, timeout=1)
    try:
        while 1:
            ser.write(Hello)
            print(Hello)
            response =ser.readline()
            if(response==ACK):
                print('ACK')
                ser.write(ACK1)
                
                break;
            else:
                print(response)

    except KeyboardInterrupt:
        ser.close()
